#!/bin/bash
ls -la
pwd
sleep 3
echo "Vou atualizar o sistema para voce digite a senha do root:"
apt-get update
clear
 

