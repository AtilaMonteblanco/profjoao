## Funções ZZ desativadas

Aqui estão estão as bravas funções que um dia brilharam na linha de comando e trouxeram alegria para seus usuários, porém, por um capricho do destino (ou uma mudança de site…), pararam de funcionar e precisaram ser aposentadas.

Mas esta aposentadoria pode ser revertida.

Se por acaso a situação mudar e alguém conseguir uma solução que faça a função voltar a funcionar, ela será reativada.

Instruções:
* [Desativando uma função](https://github.com/funcoeszz/funcoeszz/wiki/Desativando-uma-fun%C3%A7%C3%A3o)
* [Como reativar uma função desligada ](https://github.com/funcoeszz/funcoeszz/wiki/Reativar-Funcao-Desligada)
