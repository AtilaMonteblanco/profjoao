$ zzfreshmeat kde | grep '/kde$'
http://freecode.com/projects/kde
$ zzfreshmeat
Uso: zzfreshmeat programa
$
