
$ zzpiada -h

zzpiada
http://www.xalexandre.com.br/
Mostra uma piada diferente cada vez que é chamada.
Uso: zzpiada
Ex.: zzpiada

$
#$ zzpiada | sed 's/[A-ZÁÉÓÚ].*/TEXTO/ ; 3q'
#TEXTO
#
#TEXTO
#$
