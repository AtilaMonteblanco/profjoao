$ zzglobo | sed '1s/\[..[\/-]..[\/-]....\]/[DATA]/; s/^[0-9][0-9]:[0-9][0-9] - .*/HORA - DESCRIÇÃO/' | head -n 10
Hoje [DATA]

HORA - DESCRIÇÃO
HORA - DESCRIÇÃO
HORA - DESCRIÇÃO
HORA - DESCRIÇÃO
HORA - DESCRIÇÃO
HORA - DESCRIÇÃO
HORA - DESCRIÇÃO
HORA - DESCRIÇÃO
$
