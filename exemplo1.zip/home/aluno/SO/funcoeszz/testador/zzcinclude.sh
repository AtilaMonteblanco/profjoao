$ zzcinclude _fake_	#→ Não consegui ler o arquivo /usr/include/_fake_.h
$ zzcinclude /_fake_	#→ Não consegui ler o arquivo /_fake_
$ zzcinclude		#→ --regex ^Uso:

#TODO XXX como testar a saida do comando? Achar um arquivo pequeno
