$ zzwc -l zzwc.in.txt	#→ 15
$ zzwc -c zzwc.in.txt	#→ 115
$ zzwc -m zzwc.in.txt	#→ 76
$ zzwc -w zzwc.in.txt	#→ 19
$ zzwc -C zzwc.in.txt	#→ 12
$ zzwc -L zzwc.in.txt	#→ 7
$ zzwc -W zzwc.in.txt	#→ 3
$ zzwc -L -p zzwc.in.txt	#→ k l mno
$ zzwc -W -p zzwc.in.txt	#→ k l mno
$ zzwc -C -p zzwc.in.txt
9 €®ŧ←
↓→øþæ
ł»©“”
$

$ zzwc -l zzunescape.in.txt	#→ 253
$ zzwc -c zzunescape.in.txt	#→ 6398
$ zzwc -m zzunescape.in.txt	#→ 6057
$ zzwc -C zzunescape.in.txt	#→ 30
$ zzwc -L zzunescape.in.txt	#→ 28
$ zzwc -C -p zzunescape.in.txt
ℵ	&#8501;	&#x2135;	&alefsym;
