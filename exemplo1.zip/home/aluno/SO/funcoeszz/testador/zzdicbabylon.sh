$ zzdicbabylon drum
v. tocar tambor
s. tambor, caixa, tamboril
$ zzdicbabylon
Uso: zzdicbabylon [idioma] palavra   #idiomas: nl fr de he it pt es
$
