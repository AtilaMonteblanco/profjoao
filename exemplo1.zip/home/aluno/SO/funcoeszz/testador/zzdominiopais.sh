$ zzdominiopais .cx
CX - Christmas Island
$ zzdominiopais
Uso: zzdominiopais [.]código|texto
$
