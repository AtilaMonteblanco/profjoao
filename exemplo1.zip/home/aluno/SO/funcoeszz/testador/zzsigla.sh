$ zzsigla DVD
DVD   Digital Video Disc (now Digital Versatile Disc)
DVD   Digital Versatile Disc (formerly Digital Video Disc)
DVD   Dick Van Dyke (actor)
DVD   Death Valley Days (TV show)
DVD   Divide (street type)
DVD   Divers Droite (France, politics)
DVD   Deutsche Vereinigung für Datenschutz
DVD   Direct Vendor Delivery
DVD   Developmental Verbal Dyspraxia
DVD   Death Valley Driver (pro wrestling)
DVD   D-Von Dudley (wrestler)
DVD   Dissociated Vertical Deviation (ophthalmology)
DVD   Digital Video Drive
DVD   Dynamic Voltage Drop (electronics)
DvD   Depp Vom Dienst (German: Idiot of Service)
DVD   Double-Vessel Disease
DVD   Digital Virtual Disk
DVD   Drivers Vigilance Device (UK)
DVD   Driver and Vehicle Data Online Access
DVD   Diploma in Venerology & Dermatology (India)
DVD   DC Video Deluxe (skateboarding)
DVD   Definitie Van Dopeheid (Dutch: Definition of Permissible Dope)
$ zzsigla
Uso: zzsigla sigla
$
