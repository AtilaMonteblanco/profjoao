$ zzchavepgp
Uso: zzchavepgp nome|e-mail
$ zzchavepgp XXNOTFOUNDXX
   No results found: No keys found
$ zzchavepgp Guido van Rossum | sed 's/^ *//'
Type bits/keyID     Date       User ID
pub  1024D/6F023F0B 2002-10-16 Guido van Rossum <guido@python.org>
$
