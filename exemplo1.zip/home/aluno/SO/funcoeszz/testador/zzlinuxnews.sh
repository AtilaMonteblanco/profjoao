$ zzlinuxnews t  # Linux Today         #→ --lines 7
$ zzlinuxnews w  # Linux Weekly News   #→ --lines 7
$ zzlinuxnews o  # OS News             #→ --lines 7
$ zzlinuxnews s  # SlashDot            #→ --lines 7
$ zzlinuxnews i  # Linux Insider       #→ --lines 7
$ zzlinuxnews j  # Linux Journal       #→ --lines 7
$ zzlinuxnews n  # Linux News          #→ --lines 7
$ zzlinuxnews x  # LXer Linux News     #→ --lines 7
$ zzlinuxnews z
$
