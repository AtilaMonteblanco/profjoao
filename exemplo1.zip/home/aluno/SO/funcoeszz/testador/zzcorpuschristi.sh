$ zzcorpuschristi	1995	#→ 15/06/1995
$ zzcorpuschristi	1996	#→ 06/06/1996
$ zzcorpuschristi	1997	#→ 29/05/1997
$ zzcorpuschristi	1998	#→ 11/06/1998
$ zzcorpuschristi	1999	#→ 03/06/1999
$ zzcorpuschristi	2000	#→ 22/06/2000
$ zzcorpuschristi	2001	#→ 14/06/2001
$ zzcorpuschristi	2002	#→ 30/05/2002
$ zzcorpuschristi	2003	#→ 19/06/2003
$ zzcorpuschristi	2004	#→ 10/06/2004
$ zzcorpuschristi	2005	#→ 26/05/2005
$ zzcorpuschristi	2006	#→ 15/06/2006
$ zzcorpuschristi	2007	#→ 07/06/2007
$ zzcorpuschristi	2008	#→ 22/05/2008
$ zzcorpuschristi	2009	#→ 11/06/2009
$ zzcorpuschristi	2010	#→ 03/06/2010

# Erros
$ zzcorpuschristi	01/01/1970	#→ Ano inválido '01/01/1970'
$ zzcorpuschristi	-2000 		#→ Ano inválido '-2000'
$ zzcorpuschristi	0 		#→ Ano inválido '0'
$ zzcorpuschristi	foo 		#→ Ano inválido 'foo'

# Epoch
$ zzcorpuschristi	1	#→ 26/05/1
$ zzcorpuschristi	10	#→ 19/06/10
$ zzcorpuschristi	100	#→ 11/06/100
$ zzcorpuschristi	1000	#→ 30/05/1000
$ zzcorpuschristi	1969	#→ 05/06/1969
