$ zzimc  130   1,70   #→ IMC: 44.98 - OBESIDADE GRAU III
$ zzimc  110.0 1,70   #→ IMC: 38.06 - OBESIDADE GRAU II
$ zzimc  90    1,70   #→ IMC: 31.14 - OBESIDADE GRAU I
$ zzimc  80,2  1,70   #→ IMC: 27.75 - PRE-OBESIDADE
$ zzimc  70    1,70   #→ IMC: 24.22 - PESO ADEQUADO
$ zzimc  60    1,70   #→ IMC: 20.76 - PESO ADEQUADO
$ zzimc  50    1,70   #→ IMC: 17.30 - MAGREZA GRAU I
$ zzimc  48.2  1.70   #→ IMC: 16.67 - MAGREZA GRAU II
$ zzimc  40    1,70   #→ IMC: 13.84 - MAGREZA GRAU III
