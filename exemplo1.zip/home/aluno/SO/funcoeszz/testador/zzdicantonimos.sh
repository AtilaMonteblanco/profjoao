# Normal

$ zzdicantonimos alto
1. anão, raso, baixo, pequeno, reduzido, diminuto.
2. flácido, anão, caído, barato, pequeno, fraco.
3. módico, vulgar, fraco, leve, insignificante, modesto.
4. torpe, pior, sórdido, rasteiro, indigno, vil, inferior, lento, razoável.
5. acessível, cristalino, razoável, compreensível, descomplicado.
6. sopé, falda, base.
$

# Palavra com acentos

$ zzdicantonimos folgazão
1. introvertido, sério, infeliz, tristonho.
2. rancoroso.
$

# Palavra não encontrada

$ zzdicantonimos foobar
$

# Sem argumentos

$ zzdicantonimos        #→ --regex ^Uso:
