$ zzdado  #→ --regex ^[1-6]$
