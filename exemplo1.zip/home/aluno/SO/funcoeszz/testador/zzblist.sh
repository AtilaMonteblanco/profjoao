$ zzblist
Uso: zzblist IP
$ zzblist 200.199.198.197
O IP não está em nenhuma blacklist
$
