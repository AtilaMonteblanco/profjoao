$ zzdataestelar 07/10/1977              #→ 43424.07
$ zzdataestelar 25/01/2000              #→ 51569.64
$ zzdataestelar 19/02/1971              #→ 41002.41
$ zzdataestelar 06/06/1999              #→ 51336.48
$ zzdataestelar 12/04/2001              #→ 52011.94
