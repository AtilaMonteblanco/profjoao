# Exemplo: "Feliz Natal" em Esperanto: Gajan Kristnaskon

$ zznatal  #→ --regex ^"Feliz Natal" em .+: .+$
