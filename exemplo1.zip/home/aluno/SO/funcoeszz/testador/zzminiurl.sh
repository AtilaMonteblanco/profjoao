$ zzminiurl                       #→ --regex ^Uso:
$ zzminiurl funcoeszz.net         #→ --regex ^https?://(migre.me|is.gd)/[A-Za-z0-9]+$
$ zzminiurl http://funcoeszz.net  #→ --regex ^https?://(migre.me|is.gd)/[A-Za-z0-9]+$
