$ zztradutor		livro	#→ book
$ zztradutor	pt-en	livro	#→ book
$ zztradutor	pt-es	livro	#→ libro
$ zztradutor	pt-fr	livro	#→ livre
$ zztradutor	pt-it	livro	#→ libro
$ zztradutor	pt-de	livro	#→ Buch

# Via STDIN

$ echo livro | zztradutor pt-en #→ book
