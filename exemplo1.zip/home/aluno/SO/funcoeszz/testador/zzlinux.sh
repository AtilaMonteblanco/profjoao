$ zzlinux | sed 's/[0-9.]\{1,\} version/NN version/;s/\(is: *\)[^ ].*/is: VERSION/' | uniq
The latest mainline version of the Linux kernel is: VERSION
The latest stable NN version of the Linux kernel is: VERSION
The latest longterm NN version of the Linux kernel is: VERSION
The latest linux-next version of the Linux kernel is: VERSION
$
