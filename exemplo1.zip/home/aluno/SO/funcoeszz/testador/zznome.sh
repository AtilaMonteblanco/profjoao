# Sem argumentos, mostra a origem e o significado

$ zznome josé
Origem do nome Jose: BÍBLICO

Significado do nome Jose: "O QUE ACRESCENTA". FORAM VÁRIOS OS PERSONAGENS BÍBLICOS COM ESTE NOME. ENTRE ELES O MARIDO DA VIRGEM MARIA.

$

# Se $2=origem, mostra somente a origem

$ zznome josé origem
Origem do nome Jose: BÍBLICO
$
