$ zzhoroscopo                                       #→ Uso: zzhoroscopo <signo>
$ zzhoroscopo signoinvalido > /dev/null; echo $?    #→ 1
$ zzhoroscopo aquário > /dev/null; echo $?          #→ 0
$ zzhoroscopo peixes > /dev/null; echo $?           #→ 0
$ zzhoroscopo áries > /dev/null; echo $?            #→ 0
$ zzhoroscopo touro > /dev/null; echo $?            #→ 0
$ zzhoroscopo gêmeos > /dev/null; echo $?           #→ 0
$ zzhoroscopo câncer > /dev/null; echo $?           #→ 0
$ zzhoroscopo leão > /dev/null; echo $?             #→ 0
$ zzhoroscopo virgem > /dev/null; echo $?           #→ 0
$ zzhoroscopo libra > /dev/null; echo $?            #→ 0
$ zzhoroscopo escorpião > /dev/null; echo $?        #→ 0
$ zzhoroscopo sagitário > /dev/null; echo $?        #→ 0
$ zzhoroscopo capricórnio > /dev/null; echo $?      #→ 0
