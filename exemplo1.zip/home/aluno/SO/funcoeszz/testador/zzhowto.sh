$ zzhowto apache | sed '/SSL/{s/ .*//;q;}'
http://www.ibiblio.org/pub/Linux/docs/HOWTO/other-formats/html_single/
Apache+SSL+PHP+fp.html
$ zzhowto
Uso: zzhowto [--atualiza] palavra
$
