$ zzdivisores 1871          #→ 1 1871
$ zzdivisores 171           #→ 1 3 9 19 57 171
$ zzdivisores 183           #→ 1 3 61 183
$ zzdivisores 187           #→ 1 11 17 187
$ zzdivisores 177           #→ 1 3 59 177
$ zzdivisores 167           #→ 1 167
$ zzdivisores 56877         #→ 1 3 18959 56877
$ zzdivisores 5871          #→ 1 3 19 57 103 309 1957 5871
$ zzdivisores 871           #→ 1 13 67 871

$ zzdivisores 1200
1 2 3 4 5 6 8 10 12 15 16 20 24 25 30 40 48 50 60 75 80 100 120 150 200 240 300 400 600 1200
$ zzdivisores 8844
1 2 3 4 6 11 12 22 33 44 66 67 132 134 201 268 402 737 804 1474 2211 2948 4422 8844
$
