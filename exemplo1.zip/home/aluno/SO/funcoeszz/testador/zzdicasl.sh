$ zzdicasl procmail
http://www.dicas-l.com.br/arquivo/
backup_de_e-mail_com_postfix_e_procmailrc.php
bloqueando_e-mails_com_links_para_executaveis_com_procmail.php
filtragem_de_mensagens_com_procmail.php
remocao_de_mensagens_repetidas_com_procmail.php
dicas_procmail.php
configuracao_do_programa_procmail.php
evitando_cross-posting_com_procmail.php
procmail_reducao_do_tamanho_de_cabecalhos_de_mensagens.php
$ zzdicasl
Uso: zzdicasl [opção-grep] palavra(s)
$
