$ zzextensao	foo.txt		#→ txt
$ zzextensao	foo.TXT		#→ TXT
$ zzextensao	foo.bar.txt	#→ txt
$ zzextensao	foo.bar.baz.txt	#→ txt
$ zzextensao	../../foo.txt	#→ txt
$ zzextensao	'~/foo.txt'	#→ txt
$ zzextensao	'foo bar.txt'	#→ txt
$ zzextensao	/etc/passwd
$ zzextensao	.vimrc
$ zzextensao	foo.
$

