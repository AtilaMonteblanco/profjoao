$ zzcarnaval	1995		#→ 28/02/1995
$ zzcarnaval	1996		#→ 20/02/1996
$ zzcarnaval	1997		#→ 11/02/1997
$ zzcarnaval	1998		#→ 24/02/1998
$ zzcarnaval	1999		#→ 16/02/1999
$ zzcarnaval	2000		#→ 07/03/2000
$ zzcarnaval	2001		#→ 27/02/2001
$ zzcarnaval	2002		#→ 12/02/2002
$ zzcarnaval	2003		#→ 04/03/2003
$ zzcarnaval	2004		#→ 24/02/2004
$ zzcarnaval	2005		#→ 08/02/2005
$ zzcarnaval	2006		#→ 28/02/2006
$ zzcarnaval	2007		#→ 20/02/2007
$ zzcarnaval	2008		#→ 05/02/2008
$ zzcarnaval	2009		#→ 24/02/2009
$ zzcarnaval	2010		#→ 16/02/2010

# Erros
$ zzcarnaval	01/01/1970	#→ Ano inválido '01/01/1970'
$ zzcarnaval	-2000 		#→ Ano inválido '-2000'
$ zzcarnaval	0 		#→ Ano inválido '0'
$ zzcarnaval	foo 		#→ Ano inválido 'foo'

# Epoch
$ zzcarnaval	1		#→ 08/02/1
$ zzcarnaval	10 		#→ 04/03/10
$ zzcarnaval	100 		#→ 24/02/100
$ zzcarnaval	1000 		#→ 12/02/1000
$ zzcarnaval	1969 		#→ 18/02/1969
