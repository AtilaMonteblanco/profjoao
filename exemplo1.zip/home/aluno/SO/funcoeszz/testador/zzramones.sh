$ zzramones | sed 's/^.....*/TEXTO/'
TEXTO
$ zzramones UFO
Zero Zero UFO
$
