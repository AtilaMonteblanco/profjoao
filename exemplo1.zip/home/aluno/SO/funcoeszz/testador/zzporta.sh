$ zzporta 29920
Porta             Descrição
29920             Nintendo Wi-Fi Connection
$ zzporta 513
Porta             Descrição
513/TCP           Login
513/UDP           Who
513/UDP           Router
