$ zzwikipedia -pt PDP-7 | sed '/^ *$/d; s/^ *//'
PDP-7
PDP-7 modificado sendo restaurado
O DEC PDP-7 é um minicomputador produzido pela Digital Equipment Corporation. Introduzido em 1965, foi o primeiro a usar a tecnologia Flip Chip daquela companhia. Com um custo de apenas 72 mil dólares, era um computador muito barato mas bastante poderoso. Tinha uma arquitectura de 18 bits.
Em 1969, Ken Thompson escreveu o primeiro sistema UNIX em assembly num PDP-7, então chamado Unics, o que era uma brincadeira algo traiçoeira com o Multics - o sistema operativo de Space Travel, um jogo que precisava de gráficos para ilustrar os movimentos dos planetas.
Ainda restam alguns PDP-7 funcionais, e decorre em Oslo, na Noruega, um projecto de restauro.
$ zzwikipedia
Uso: zzwikipedia [-idioma] palavra(s)
$
$ zzwikipedia -xx
Uso: zzwikipedia [-idioma] palavra(s)
$
