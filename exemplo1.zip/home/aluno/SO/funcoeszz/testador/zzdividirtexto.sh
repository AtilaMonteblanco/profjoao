$ zzlorem 300 | zzdividirtexto 15
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin euismod blandit pharetra. Vestibulum eu neque
 eget lorem gravida commodo a cursus massa. Fusce sit amet lorem sem. Donec eu quam
 leo. Suspendisse consequat risus in ante fringilla sit amet facilisis felis hendrerit. Suspendisse potenti. Pellentesque
 enim quam, cursus vestibulum porta ac, pharetra vitae ipsum. Sed ullamcorper odio eget diam egestas
 lacinia. Aenean aliquam tortor quis dolor sollicitudin suscipit. Etiam nec libero vitae magna dignissim molestie.
 Pellentesque volutpat euismod justo id congue. Proin nibh magna, blandit quis posuere at, sollicitudin nec
 lectus. Vivamus ut erat erat, in egestas lacus. Vivamus vel nunc elit, ut aliquam nisi.
 Vivamus convallis, mi eu consequat scelerisque, lacus lorem elementum quam, vel varius augue lectus sit
 amet nulla. Integer porta ligula eu risus rhoncus sit amet blandit nulla tincidunt. Nullam fringilla
 lectus scelerisque elit suscipit venenatis. Donec in ante nec tortor mollis adipiscing. Aliquam id tellus
 bibendum orci ultricies scelerisque sit amet ut elit. Sed quis turpis molestie tortor consectetur dapibus.
 Donec hendrerit diam sit amet nibh porta a pellentesque tortor dictum. Curabitur justo libero, rhoncus
 vitae facilisis nec, vulputate at ipsum. Quisque iaculis diam eget mi tincidunt id sollicitudin diam
 fermentum. Vivamus sed orci non nisl elementum adipiscing in et tortor. Class aptent taciti sociosqu
 ad litora torquent per conubia nostra, per inceptos himenaeos. Class aptent taciti sociosqu ad litora
 torquent per conubia nostra, per inceptos himenaeos. In hac habitasse platea dictumst. Phasellus a dictum
 magna. Duis vel erat in lacus tempor fermentum sit amet sed felis. Vestibulum arcu libero,
 convallis sed euismod sit amet, condimentum in orci. Nulla tempus venenatis justo, et porttitor metus
 pellentesque ut. Nunc vel turpis a risus mollis tempor. Suspendisse purus risus, pharetra eu tincidunt
 non, adipiscing vitae libero. Nam ut quam sed metus laoreet sagittis vel non risus.
$ zzlorem 12 | zzdividirtexto 5
Lorem ipsum dolor sit amet,
 consectetur adipiscing elit. Proin euismod
 blandit pharetra.
$ zzlorem 22 | sed 's/\. /./g' | zzdividirtexto 4
Lorem ipsum dolor sit
 amet, consectetur adipiscing elit.Proin
 euismod blandit pharetra.Vestibulum eu
 neque eget lorem gravida
 commodo a cursus massa.
$ zzdividirtexto 3 Uma frase longa, para ter um assunto extenso, que possa ser desculpa para alongar a prosa!
Uma frase longa,
 para ter um
 assunto extenso, que
 possa ser desculpa
 para alongar a
 prosa!
