$ zzrpmfind vim | sed 's/^  [a-z].*\.rpm$/  URL/' | sed 5q
ftp://rpmfind.net/linux/
  URL
  URL
  URL
  URL
$ zzrpmfind foobar
$
