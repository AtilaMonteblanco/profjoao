$ zzchecamd5 _numeros.txt a7b1ac3a2b072f71a8e0d463bf4eb822    #→ Imagem OK
$ zzchecamd5 _vazio.txt   d41d8cd98f00b204e9800998ecf8427e    #→ Imagem OK
$ zzchecamd5 _dados.txt   a48adf5366ffc7e0a6eb60447502c18e    #→ Imagem OK
$ zzchecamd5 _dados.txt   a7b1ac3a2b072f71a8e0d463bf4eb822    #→ O md5sum nao confere!!
