$ zzcep Rua Santa Ifigênia
LOGRADOURO                                                        BAIRRO                    CIDADE/ESTADO                  CEP
Rua Santa Ifigenia                                                Residencial São Luis      Francisco Morato, SP           07996-000
Rua Santa Ifigênia - lado ímpar                                   Santa Efigênia            São Paulo, SP                  01207-001
Rua Santa Ifigênia 75                                             Santa Efigênia            São Paulo, SP                  01207-900
Rua Santa Ifigênia - lado par                                     Santa Efigênia            São Paulo, SP                  01207-000
$

$ zzcep 01310-000
LOGRADOURO                                                        BAIRRO                    CIDADE/ESTADO
Avenida Paulista - até 610 - lado par                             Bela Vista                São Paulo, SP
$

$ zzcep 01234-001
LOGRADOURO                                                        BAIRRO                    CIDADE/ESTADO
Avenida Pacaembu - de 501 ao fim - lado ímpar                     Pacaembu                  São Paulo, SP
$

$ zzcep 01234-000
LOGRADOURO                                                        BAIRRO                    CIDADE/ESTADO
Avenida Pacaembu - de 502 ao fim - lado par                       Pacaembu                  São Paulo, SP
$

$ zzcep Av. Novo Osasco
LOGRADOURO                                                        BAIRRO                    CIDADE/ESTADO                  CEP
Avenida Novo Osasco - lado par                                    Bussocaba                 Osasco, SP                     06056-000
Avenida Novo Osasco - lado ímpar                                  Bussocaba                 Osasco, SP                     06056-010
$
