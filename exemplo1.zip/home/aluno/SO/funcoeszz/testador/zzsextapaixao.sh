$ zzsextapaixao	1995	#→ 14/04/1995
$ zzsextapaixao	1996	#→ 05/04/1996
$ zzsextapaixao	1997	#→ 28/03/1997
$ zzsextapaixao	1998	#→ 10/04/1998
$ zzsextapaixao	1999	#→ 02/04/1999
$ zzsextapaixao	2000	#→ 21/04/2000
$ zzsextapaixao	2001	#→ 13/04/2001
$ zzsextapaixao	2002	#→ 29/03/2002
$ zzsextapaixao	2003	#→ 18/04/2003
$ zzsextapaixao	2004	#→ 09/04/2004
$ zzsextapaixao	2005	#→ 25/03/2005
$ zzsextapaixao	2006	#→ 14/04/2006
$ zzsextapaixao	2007	#→ 06/04/2007
$ zzsextapaixao	2008	#→ 21/03/2008
$ zzsextapaixao	2009	#→ 10/04/2009
$ zzsextapaixao	2010	#→ 02/04/2010

# Erros

$ zzsextapaixao	01/01/1970	#→ Ano inválido '01/01/1970'
$ zzsextapaixao	-2000 		#→ Ano inválido '-2000'
$ zzsextapaixao	0 		#→ Ano inválido '0'
$ zzsextapaixao	foo 		#→ Ano inválido 'foo'

# Epoch

$ zzsextapaixao	1	#→ 25/03/1
$ zzsextapaixao	10 	#→ 18/04/10
$ zzsextapaixao	100 	#→ 10/04/100
$ zzsextapaixao	1000	#→ 29/03/1000
$ zzsextapaixao	1969 	#→ 04/04/1969
