$ zzcotacao | sed 's/[0-9],[0-9]\{3\}/9.999/g;s|  n/d|9.999|g;s/[+_]/ /g;s/-/ /g;s/[0-9],[0-9]\{2\}/9.99/g'
                    Compra   Venda   Var(%)
Dolar Comercial      9.999   9.999    9.99
Dolar Turismo        9.999   9.999    9.99
Dolar PTAX800        9.999   9.999    9.99
Euro                 9.999   9.999    9.99
Iene                 9.999   9.999    9.99
Franco Suico         9.999   9.999    9.99
Peso Argentino       9.999   9.999    9.99
Libra Esterlina      9.999   9.999    9.99
Dolar Canadense      9.999   9.999    9.99
Dolar Australiano    9.999   9.999    9.99
$
