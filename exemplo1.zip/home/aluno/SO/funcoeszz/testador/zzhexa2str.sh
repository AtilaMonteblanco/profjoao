# a-f
$ zzhexa2str	"62 69 6e 61 72 69 6f"			#→ binario
# A-F
$ zzhexa2str	"62 69 6E 61 72 69 6F"			#→ binario
# A-F, prefixo 0x
$ zzhexa2str	"0x62 0x69 0x6e 0x61 0x72 0x69 0x6F"	#→ binario
