$ zzgoogle -n 1 ab-rephone github	#→ --lines 3
$ zzgoogle
Uso: zzgoogle [-n <número>] palavra(s)
$
