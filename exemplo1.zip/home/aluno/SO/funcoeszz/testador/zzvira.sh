$ zzvira 'Inverte tudo'
odut etrevnI
$ zzvira -X 'De pernas pro ar'
ɹɐ oɹd sɐuɹǝd ǝp
$
