$ zzlocale
Uso: zzlocale [-c] código|texto
$ zzlocale chinese
Chinese, Simplified (China) zh_CN.gb18030
Chinese, Simplified (China) zh_CN.hp15CN
Chinese, Simplified (China) zh_CN.utf8
Chinese, Traditional (Hong Kong) zh_HK.hkbig5
Chinese, Traditional (Hong Kong) zh_HK.utf8
Chinese, Traditional (Taiwan) zh_TW.big5
Chinese, Traditional (Taiwan) zh_TW.ccdc
Chinese, Traditional (Taiwan) zh_TW.eucTW
Chinese, Traditional (Taiwan) zh_TW.utf8
$ zzlocale -c pt
Portuguese (Brazil) pt_BR.iso88591
Portuguese (Brazil) pt_BR.iso885915
Portuguese (Brazil) pt_BR.utf8
Portuguese (Portugal) pt_PT.iso88591
Portuguese (Portugal) pt_PT.iso885915@euro
Portuguese (Portugal) pt_PT.roman8
Portuguese (Portugal) pt_PT.utf8
$
