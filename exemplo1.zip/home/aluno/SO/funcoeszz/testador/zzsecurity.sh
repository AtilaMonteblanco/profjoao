$ zzsecurity debian      #→ --lines 8
$ zzsecurity freebsd     #→ --lines 8
$ zzsecurity gentoo      #→ --lines 8
$ zzsecurity slackware   #→ --lines 8
$ zzsecurity suse        #→ --lines 16
$ zzsecurity opensuse    #→ --lines 16
$ zzsecurity ubuntu      #→ --lines 8
$ zzsecurity arch        #→ --lines 8
$ zzsecurity mageia      #→ --lines 8
$ zzsecurity netbsd      #→ --lines 8
$ zzsecurity fedora      #→ --lines 8
$ zzsecurity foo
$
