# Americano
$ zzmacvendor 84:B8:02:43:E1:D0
Fabricante: Cisco Systems, Inc
Endereço:   170 West Tasman Drive,San Jose CA 95134
País:       United States
$

# Coreano
$ zzmacvendor 50-55-27-A3-A9-89
Fabricante: LG Electronics
Endereço:   60-39, Gasan-dong, Geumcheon-gu,Seoul 153-801
País:       Korea (South)
$

# Brasileiro
$ zzmacvendor 00:1A:3F:6A:05:79
Fabricante: intelbras
Endereço:   rodovia br 101 km 210,sao jose sc 88104800
País:       Brazil
$

# Japonês
$ zzmacvendor F0-27-65-5B-41-D1
Fabricante: Murata Manufacturing Co., Ltd.
Endereço:   1-10-1 Higashikotari,Nagaokakyo-shi Kyoto 617-8555
País:       Japan
$

# Malaio
$ zzmacvendor 00-23-14-e3-ff-a8
Fabricante: Intel Corporate
Endereço:   Lot 8, Jalan Hi-Tech 2/3,Kulim Kedah 09000
País:       Malaysia
$

# Taiwan
$ zzmacvendor 00-0D-F0-AD-9D-67
Fabricante: QCOM TECHNOLOGY INC.
Endereço:   7F., NO 178, MING CHUAN E. RD., SEC. 3,,TAIPEI 105
País:       Taiwan
$

# China
$ zzmacvendor 7C:E9:D3:4F:2C:EB
Fabricante: Hon Hai Precision Ind. Co.,Ltd.
Endereço:   NO.1925,Nanle Road ,Songjiang Export Processing Zone,Shanghai 201613
País:       China
$

# Sueco
$ zzmacvendor 44:74:6C:F2:2E:0F
Fabricante: Sony Mobile Communications AB
Endereço:   Nya Vattentornet,Lund SE 22128
País:       Sweden
$

# Erro
$ zzmacvendor 44:74:6C:e3-ff-a8	#→ MAC address inválido '44:74:6C:e3-ff-a8'
$ zzmacvendor A3-A9-89-G0-23-14	#→ MAC address inválido 'A3-A9-89-G0-23-14'
$ zzmacvendor B802430DF0AD	#→ MAC address inválido 'B802430DF0AD'
