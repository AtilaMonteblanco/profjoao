$ zzcaracoroa  #→ --regex ^(Cara|Coroa)$
