$ zzlibertadores 2                      #→ --lines 112
$ zzlibertadores -g 5                   #→ --lines 13
$ zzlibertadores -cg 2                  #→ --lines 18
$ zzlibertadores -c                     #→ --lines 48
