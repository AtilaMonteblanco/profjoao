$ zznoticiassec c  # CERT/CC                  #→ --lines 7
$ zznoticiassec s  # Linux Security           #→ --lines 7
$ zznoticiassec t  # Linux Today - Security   #→ --lines 7
$ zznoticiassec f  # Security Focus           #→ --lines 7
$ zznoticiassec z
$
