$ zzdefinr headphone
headphone (http://definr.com/headphone)
     n : electro-acoustic transducer for converting electric signals
         into sounds; it is held over or inserted into the ear;
         "it was not the typing but the earphones that she
         disliked" [syn: earphone, earpiece, phone]
$ zzdefinr
Uso: zzdefinr termo
$
