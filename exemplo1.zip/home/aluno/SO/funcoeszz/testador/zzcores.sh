$ zzcores  #→ --file zzcores.out.ansi
