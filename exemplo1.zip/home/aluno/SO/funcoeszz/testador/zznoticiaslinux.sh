$ zznoticiaslinux b  # BR-Linux        #→ --lines 7
$ zznoticiaslinux d  # Diolinux        #→ --lines 7
$ zznoticiaslinux e  # Espírito Livre  #→ --lines 7
$ zznoticiaslinux u  # Under Linux     #→ --lines 7
$ zznoticiaslinux v  # Viva o Linux    #→ --lines 7
$ zznoticiaslinux z
$
