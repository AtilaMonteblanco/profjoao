#!/bin/bash
echo "Seu nome de usuário é:"
ÁtilaMonteblanco
echo "Info de hora atual e tempo que o computador esta ligado"
uptime
echo "O script esta executando do diretório:"
pwd


